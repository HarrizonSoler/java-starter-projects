package usta.sistemas;

import javax.swing.*;
import java.awt.*;

public class Main {

    /*
      Name: Harrizon Alexander Soler Galindo
      Date: 17/06/2020
      Description: This class call the FormStart Window;
    */

    public static void main(String[] args) {
	FormStart start = new FormStart(); //Call the new Window
    }
}
